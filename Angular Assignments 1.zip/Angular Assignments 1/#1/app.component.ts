import { Component } from '@angular/core';  
@Component({ 
    selector: 'app-root', 
    templateUrl: 'app.component.html' 
}) 
export class AppComponent { 
    nResults: number = 0;
	constructor(){
		console.log("constructor.....");
		this.met1();
	} 

	met1(){
		setInterval(()=>{
			this.nResults++;
		},1000);
	}
}