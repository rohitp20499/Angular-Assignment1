import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
//import { AbcdComponent } from './abcd/abcd.component';

//AbcdComponent
@NgModule({
  declarations: [
    AppComponent,
     ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
