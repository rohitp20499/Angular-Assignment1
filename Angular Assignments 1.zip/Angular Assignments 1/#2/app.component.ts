import { Component } from '@angular/core';  
@Component({ 
    selector: 'app-root', 
    templateUrl: 'app.component.html' 
}) 
export class AppComponent { 
    nResults: number = 0;
	constructor(){
		console.log("constructor.....");
	} 

	incrementVal(){
		this.nResults++;
	}
	decrementVal(){
		this.nResults--;
	}
}