import { Component } from '@angular/core';  
@Component({ 
    selector: 'app-root', 
    templateUrl: 'app.component.html' 
}) 
export class AppComponent { 
    nResults: number = 0;
	constructor(){
		console.log("constructor.....");
	} 

	met1(){
		if(this.nResults>=10){
			this.nResults=10;
		}else{
			this.nResults++;
		}
	} 
	met2(){
		if(this.nResults<=0){
			this.nResults=0;
		}else{
			this.nResults--;
		}
	} 
}