import { Component } from '@angular/core';
import { User } from './user.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
isValid = true;
ids = [1,2,3,4];
title = 'app';

	users = [
      new User('Mahesh', 20),
      new User('Krishna', 22),
      new User('Narendra', 31)
    ];
 }


