export class User {
    constructor(public name: string, public age: number) { 
    }
  }