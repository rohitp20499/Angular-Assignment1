import { Component} from '@angular/core';

@Component({
	selector: 'app-root',
	templateUrl: './app.component.html'
})
export class AppComponent{
//   myMsg = 'Angular 11 App';
  
  myNum: number = 7;

  myarr:number[] = [1,2,3,4,5,6,7,8,9,10];
}